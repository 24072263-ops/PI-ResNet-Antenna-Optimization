# %%
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader, random_split
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from scipy.optimize import differential_evolution
import itertools
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Running on: {DEVICE}")

# %%
WAVELENGTH = 241.12   
THETA_R = 6.283        
INPUT_DIM = 6          
BATCH_SIZE = 32
EPOCHS = 100

# %%
import pandas as pd
path = "C:\\Users\\Shafat\\Desktop\\thesis progress\\final_sorted_dataset.xlsx"
df = pd.read_excel(path)
df.head()


# %%
cols_to_remove = ['Upper_frequency', 'Lower_frequency', 'center_frequency','patch_thickness','substrate_thickness', 'feedline_width']

# 2. Drop them
# axis=1 means "look for columns" (axis=0 would look for rows)
df = df.drop(columns=cols_to_remove)

# Verify they are gone
print(df.head())

# %%
df.isna().sum()

# %%
df.columns

# %%
correlation_matrix = df.corr()
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import LogisticRegression
# Plot the heatmap
plt.figure(figsize=(8,6))
sns.heatmap(correlation_matrix, annot=True, cmap="coolwarm", fmt=".2f", linewidths=0.5)

plt.title("Correlation Matrix")
plt.show()

# %%
class AntennaDataset(Dataset):
    def __init__(self, dataframe, scaler=None, y_phys_scaler=None):
        # 1. Inputs (6 features)
        self.X_raw = dataframe[['Ant_length', 'Ant_width', 'patch_radius',
                                'inset_width', 'inset_length', 'mutual_gap']].values.astype(np.float32)

        # 2. Physics Targets (Efficiency, FBW, Area)
        self.y_phys_raw = dataframe[['Avg_efficiency', 'FBW', 'Total Area (mm^2)']].values.astype(np.float32)

        # 3. Final Target (FoM) - KEEP RAW (Real Physics Units)
        self.y_fom_raw = dataframe[['FoMt']].values.astype(np.float32)

        # 4. Standardization
        # Scale Inputs
        if scaler is None:
            self.scaler = StandardScaler()
            self.X = self.scaler.fit_transform(self.X_raw)
        else:
            self.scaler = scaler
            self.X = self.scaler.transform(self.X_raw)

        # Scale Physics Targets (Crucial for training stability)
        if y_phys_scaler is None:
            self.y_phys_scaler = StandardScaler()
            self.y_physics = self.y_phys_scaler.fit_transform(self.y_phys_raw)
        else:
            self.y_phys_scaler = y_phys_scaler
            self.y_physics = self.y_phys_scaler.transform(self.y_phys_raw)

        # Do NOT Scale FoM (We use real physics output to compare)
        self.y_fom = self.y_fom_raw

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        # Returns: (Scaled Inputs, Scaled Physics Targets, Real FoM Target)
        return self.X[idx], self.y_physics[idx], self.y_fom[idx]


# %% [markdown]
# 3. LOAD DATA

# %%
# --- Data Loading and Processing Pipeline ---

# 1. Load data
df = pd.read_excel(path)

# 2. Split the raw DataFrame before scaling (70% train, 15% val, 15% test)
train_df, temp_df = train_test_split(df, test_size=0.30, random_state=42)
val_df, test_df = train_test_split(temp_df, test_size=0.50, random_state=42)

# 3. Instantiate the training dataset first (this triggers fit_transform internally)
train_data = AntennaDataset(train_df)

# 4. Instantiate validation and test datasets using the scalers fitted on the training data
val_data = AntennaDataset(val_df, 
                          scaler=train_data.scaler, 
                          y_phys_scaler=train_data.y_phys_scaler)

test_data = AntennaDataset(test_df, 
                           scaler=train_data.scaler, 
                           y_phys_scaler=train_data.y_phys_scaler)

# 5. Create DataLoaders
train_loader = DataLoader(train_data, batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(val_data, batch_size=BATCH_SIZE, shuffle=False)
test_loader = DataLoader(test_data, batch_size=BATCH_SIZE, shuffle=False)

print(f"Data Loaded: {len(train_data)} Training Samples")
print(f"Data Loaded: {len(val_data)} Validation Samples")
print(f"Data Loaded: {len(test_data)} Testing Samples")

# %% [markdown]
# 4. MODEL COMPONENTS

# %%
class ResidualBlock(nn.Module):
    def __init__(self, hidden_dim, dropout_rate=0.3):
        super().__init__()
        self.block = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim)
        )
        self.activation = nn.ReLU()

    def forward(self, x):
        return self.activation(x + self.block(x))

class FoMEquationLayer(nn.Module):
    def __init__(self, wavelength, theta_r):
        super().__init__()
        self.wavelength = wavelength
        self.theta_r = theta_r
        self.register_buffer('pi', torch.tensor(3.14159265359))

    def forward(self, efficiency, fbw, area):
        numerator = efficiency * fbw
        denom_term = (4 * self.pi * area) / (self.theta_r * (self.wavelength ** 2))
        ratio = numerator / (denom_term + 1e-8)
        fom_t = 10 * (torch.log(ratio + 1e-8) / torch.log(torch.tensor(10.0)))
        return fom_t

class AdvancedPIDLModel(nn.Module):
    def __init__(self, input_dim, hidden_dim=128, num_blocks=3, phys_scaler=None):
        super().__init__()
        self.input_layer = nn.Sequential(nn.Linear(input_dim, hidden_dim), nn.ReLU())

        # Stack ResNet Blocks
        layers = [ResidualBlock(hidden_dim) for _ in range(num_blocks)]
        self.backbone = nn.Sequential(*layers)

        # Store Scaler Stats inside the model
        if phys_scaler is not None:
            self.register_buffer('phys_mean', torch.tensor(phys_scaler.mean_, dtype=torch.float32))
            self.register_buffer('phys_scale', torch.tensor(phys_scaler.scale_, dtype=torch.float32))
        else:
            self.register_buffer('phys_mean', torch.zeros(3))
            self.register_buffer('phys_scale', torch.ones(3))

        # Output Heads (No activation - predicting Scaled Z-scores)
        self.head_eff = nn.Linear(hidden_dim, 1)
        self.head_fbw = nn.Linear(hidden_dim, 1)
        self.head_area = nn.Linear(hidden_dim, 1)

        self.physics_layer = FoMEquationLayer(WAVELENGTH, THETA_R)

    def forward(self, x):
        x = self.input_layer(x)
        features = self.backbone(x)

        # 1. Predict SCALED values
        pred_eff_scaled = self.head_eff(features)
        pred_fbw_scaled = self.head_fbw(features)
        pred_area_scaled = self.head_area(features)

        # 2. Un-scale to get REAL values
        eff_real = (pred_eff_scaled * self.phys_scale[0]) + self.phys_mean[0]
        fbw_real = (pred_fbw_scaled * self.phys_scale[1]) + self.phys_mean[1]
        area_real = (pred_area_scaled * self.phys_scale[2]) + self.phys_mean[2]

        # 3. Enforce Physics Constraints on REAL values
        eff_real = torch.relu(eff_real) + 1e-6
        fbw_real = torch.relu(fbw_real) + 1e-6
        area_real = torch.relu(area_real) + 1e-6

        # 4. Calculate FoM using REAL values
        pred_fom = self.physics_layer(eff_real, fbw_real, area_real)

        return pred_fom, pred_eff_scaled, pred_fbw_scaled, pred_area_scaled

# %%
bounds = [
    (1e-4, 1e-2),  # Learning rate
    (256, 1024),     # Hidden dimension
    (3, 7)         # Number of residual blocks
]

print("Hyperparameter search space (bounds) defined:")
for i, (min_val, max_val) in enumerate(bounds):
    if i == 0:
        print(f"  Learning Rate: {min_val} to {max_val}")
    elif i == 1:
        print(f"  Hidden Dimension: {min_val} to {max_val}")
    elif i == 2:
        print(f"  Number of Residual Blocks: {min_val} to {max_val}")

# %%
def objective_function(params):
    # Ensure integer hyperparameters are cast to int
    lr = params[0]
    hidden_dim = int(params[1])
    num_blocks = int(params[2])

    # Instantiate model with current hyperparameters
    model = AdvancedPIDLModel(
        input_dim=INPUT_DIM,
        hidden_dim=hidden_dim,
        num_blocks=num_blocks,
        phys_scaler=train_data.y_phys_scaler
    ).to(DEVICE)

    optimizer = optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()

    # Train for a few epochs to get an initial performance estimate
    # Using a small number of epochs to speed up tuning process
    TUNE_EPOCHS = 5 # Reduced epochs for tuning efficiency

    for epoch in range(TUNE_EPOCHS):
        model.train()
        for bx, by_phys_scaled, by_fom_real in train_loader:
            bx = bx.to(DEVICE)
            by_phys_scaled = by_phys_scaled.to(DEVICE)
            by_fom_real = by_fom_real.to(DEVICE)

            optimizer.zero_grad()
            p_fom_real, p_eff_scaled, p_fbw_scaled, p_area_scaled = model(bx)

            loss_eff = loss_fn(p_eff_scaled, by_phys_scaled[:, 0:1])
            loss_fbw = loss_fn(p_fbw_scaled, by_phys_scaled[:, 1:2])
            loss_area = loss_fn(p_area_scaled, by_phys_scaled[:, 2:3])
            loss = loss_fn(p_fom_real, by_fom_real) + loss_eff + loss_fbw + loss_area

            loss.backward()
            optimizer.step()

    # Evaluate on validation set
    model.eval()
    val_loss = 0
    with torch.no_grad():
        for bx, by_phys_scaled, by_fom_real in val_loader:
            bx = bx.to(DEVICE)
            by_phys_scaled = by_phys_scaled.to(DEVICE)
            by_fom_real = by_fom_real.to(DEVICE)

            p_fom_real, p_eff_scaled, p_fbw_scaled, p_area_scaled = model(bx)

            loss_eff = loss_fn(p_eff_scaled, by_phys_scaled[:, 0:1])
            loss_fbw = loss_fn(p_fbw_scaled, by_phys_scaled[:, 1:2])
            loss_area = loss_fn(p_area_scaled, by_phys_scaled[:, 2:3])
            loss = loss_fn(p_fom_real, by_fom_real) + loss_eff + loss_fbw + loss_area
            val_loss += loss.item()

    return val_loss / len(val_loader)

print("Objective function 'objective_function' defined.")

print("\n--- Starting Hyperparameter Optimization with Differential Evolution ---")

result = differential_evolution(
    objective_function,
    bounds,
    strategy='best1bin', # Common strategy for differential evolution
    popsize=10,          # Population size factor (default 15)
    mutation=(0.5, 1),   # Mutation rate
    recombination=0.7,   # Crossover probability
    maxiter=20,          # Number of generations/iterations (keep low for faster tuning)
    disp=True,           # Display progress
    polish=True,         # Optimize the best solution found with L-BFGS-B
    workers=-1           # Use all available CPU cores
)

print("\n--- Optimization Complete ---")
print(f"Best validation loss: {result.fun:.4f}")
print(f"Best hyperparameters: {result.x}")

best_lr = result.x[0]
best_hidden_dim = int(result.x[1])
best_num_blocks = int(result.x[2])

print(f"  Learning Rate: {best_lr:.6f}")
print(f"  Hidden Dimension: {best_hidden_dim}")
print(f"  Number of Residual Blocks: {best_num_blocks}")

# %%
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
import time
from sklearn.metrics import mean_absolute_error, r2_score

plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman'],
    'font.size': 14,          # Base font size
    'axes.titlesize': 16,     # Font size for subplot titles
    'axes.labelsize': 14,     # Font size for X and Y labels
    'legend.fontsize': 14,    # Font size for the legend
    'xtick.labelsize': 12,    # Font size for X axis tick marks
    'ytick.labelsize': 12     # Font size for Y axis tick marks
})

FIXED_LR = 0.007767
FIXED_HIDDEN_DIM = 412
FIXED_NUM_BLOCKS = 3 # Using a common value from previous runs

print("\n--- Training Model with Fixed Hyperparameters and Early Stopping ---")
print(f"  Fixed Learning Rate: {FIXED_LR:.6f}")
print(f"  Fixed Hidden Dimension: {FIXED_HIDDEN_DIM}")
print(f"  Fixed Number of Residual Blocks: {FIXED_NUM_BLOCKS}")

fixed_model = AdvancedPIDLModel(
    input_dim=INPUT_DIM,
    hidden_dim=FIXED_HIDDEN_DIM,
    num_blocks=FIXED_NUM_BLOCKS,
    phys_scaler=train_data.y_phys_scaler
).to(DEVICE)

fixed_optimizer = optim.Adam(fixed_model.parameters(), lr=FIXED_LR)
scheduler_fixed = torch.optim.lr_scheduler.ReduceLROnPlateau(
    fixed_optimizer, mode='min', factor=0.5, patience=5
)
fixed_loss_fn = nn.HuberLoss(delta=1.0)

FULL_EPOCHS = 200
PATIENCE = 20    

train_losses_fixed_hp = []
val_losses_fixed_hp = []
best_val_loss_fixed_hp = float('inf')
patience_counter_fixed_hp = 0
best_model_state_fixed_hp = None
if DEVICE.type == "cuda":
    torch.cuda.synchronize()

training_start_time = time.perf_counter()

for epoch in range(FULL_EPOCHS):
    fixed_model.train()
    total_train_loss = 0
    for bx, by_phys_scaled, by_fom_real in train_loader:
        bx = bx.to(DEVICE)
        by_phys_scaled = by_phys_scaled.to(DEVICE)
        by_fom_real = by_fom_real.to(DEVICE)

        fixed_optimizer.zero_grad()
        p_fom_real, p_eff_scaled, p_fbw_scaled, p_area_scaled = fixed_model(bx)

        loss_eff = fixed_loss_fn(p_eff_scaled, by_phys_scaled[:, 0:1])
        loss_fbw = fixed_loss_fn(p_fbw_scaled, by_phys_scaled[:, 1:2])
        loss_area = fixed_loss_fn(p_area_scaled, by_phys_scaled[:, 2:3])
        loss_fom = fixed_loss_fn(p_fom_real, by_fom_real)

        total_loss = loss_fom + loss_eff + loss_fbw + loss_area

        total_loss.backward()
        fixed_optimizer.step()
        total_train_loss += total_loss.item()

    avg_train_loss = total_train_loss / len(train_loader)
    train_losses_fixed_hp.append(avg_train_loss)

    # Evaluate on validation set after each epoch
    fixed_model.eval()
    total_val_loss = 0
    with torch.no_grad():
        for bx, by_phys_scaled, by_fom_real in val_loader:
            bx = bx.to(DEVICE)
            by_phys_scaled = by_phys_scaled.to(DEVICE)
            by_fom_real = by_fom_real.to(DEVICE)

            p_fom_real, p_eff_scaled, p_fbw_scaled, p_area_scaled = fixed_model(bx)

            loss_eff = fixed_loss_fn(p_eff_scaled, by_phys_scaled[:, 0:1])
            loss_fbw = fixed_loss_fn(p_fbw_scaled, by_phys_scaled[:, 1:2])
            loss_area = fixed_loss_fn(p_area_scaled, by_phys_scaled[:, 2:3])
            loss_fom = fixed_loss_fn(p_fom_real, by_fom_real)

            total_loss = loss_fom + loss_eff + loss_fbw + loss_area
            total_val_loss += total_loss.item() * bx.size(0)

    avg_val_loss = total_val_loss / len(val_loader.dataset)
    val_losses_fixed_hp.append(avg_val_loss)

    # Step the Scheduler
    scheduler_fixed.step(avg_val_loss)

    # Early stopping logic
    if avg_val_loss < best_val_loss_fixed_hp:
        best_val_loss_fixed_hp = avg_val_loss
        patience_counter_fixed_hp = 0
        best_model_state_fixed_hp = fixed_model.state_dict() # Save best model state
    else:
        patience_counter_fixed_hp += 1

    if (epoch + 1) % 2 == 0:
        print(f"Epoch {epoch+1}/{FULL_EPOCHS} | Training Loss: {avg_train_loss:.4f} | Validation Loss: {avg_val_loss:.4f} | Patience: {patience_counter_fixed_hp}/{PATIENCE}")

    if patience_counter_fixed_hp >= PATIENCE:
        print(f"Early stopping triggered after {epoch + 1} epochs. Validation loss did not improve for {PATIENCE} epochs.")
        break
if DEVICE.type == "cuda":
    torch.cuda.synchronize()

training_time = time.perf_counter() - training_start_time

print("\n--- PI-ResNet Training Time ---")
print(f"Total training time: {training_time:.2f} seconds")
print(f"Total training time: {training_time/60:.2f} minutes")
# Load the best model state found during training
if best_model_state_fixed_hp is not None:
    fixed_model.load_state_dict(best_model_state_fixed_hp)
    print("Loaded best model state from early stopping.")

# 🟢 INSERT THE SAVING CODE RIGHT HERE 🟢
# ==========================================
save_path = "best_pidl_antenna_model.pth"
checkpoint = {
    'model_state_dict': fixed_model.state_dict(),
    'hidden_dim': FIXED_HIDDEN_DIM,
    'num_blocks': FIXED_NUM_BLOCKS,
    'learning_rate': FIXED_LR,
    'optimizer_state_dict': fixed_optimizer.state_dict() 
}
torch.save(checkpoint, save_path)
print(f"Model successfully saved to {save_path}")
# ==========================================


print("\n--- Evaluating Fixed Model on Test Set ---")
fixed_model.eval()

test_loss_eff_fixed_hp = 0
test_loss_fbw_fixed_hp = 0
test_loss_area_fixed_hp = 0
test_loss_fom_fixed_hp = 0

all_preds_fom_fixed_hp, all_preds_eff_fixed_hp, all_preds_fbw_fixed_hp, all_preds_area_fixed_hp = [], [], [], []
all_true_fom_fixed_hp, all_true_eff_fixed_hp, all_true_fbw_fixed_hp, all_true_area_fixed_hp = [], [], [], []

with torch.no_grad():
    for bx, by_phys_scaled, by_fom_real in test_loader:
        bx = bx.to(DEVICE)
        by_phys_scaled = by_phys_scaled.to(DEVICE)
        by_fom_real = by_fom_real.to(DEVICE)

        p_fom_real, p_eff_scaled, p_fbw_scaled, p_area_scaled = fixed_model(bx)

        loss_eff = fixed_loss_fn(p_eff_scaled, by_phys_scaled[:, 0:1])
        loss_fbw = fixed_loss_fn(p_fbw_scaled, by_phys_scaled[:, 1:2])
        loss_area = fixed_loss_fn(p_area_scaled, by_phys_scaled[:, 2:3])
        loss_fom = fixed_loss_fn(p_fom_real, by_fom_real)

        test_loss_eff_fixed_hp += loss_eff.item()
        test_loss_fbw_fixed_hp += loss_fbw.item()
        test_loss_area_fixed_hp += loss_area.item()
        test_loss_fom_fixed_hp += loss_fom.item()

        # Collect predictions and true values (unscaled for physics and FoM)
        eff_real_pred = (p_eff_scaled * fixed_model.phys_scale[0]) + fixed_model.phys_mean[0]
        fbw_real_pred = (p_fbw_scaled * fixed_model.phys_scale[1]) + fixed_model.phys_mean[1]
        area_real_pred = (p_area_scaled * fixed_model.phys_scale[2]) + fixed_model.phys_mean[2]

        all_preds_fom_fixed_hp.extend(p_fom_real.cpu().numpy().flatten())
        all_true_fom_fixed_hp.extend(by_fom_real.cpu().numpy().flatten())
        all_preds_eff_fixed_hp.extend(eff_real_pred.cpu().numpy().flatten())
        all_true_eff_fixed_hp.extend(train_data.y_phys_scaler.inverse_transform(by_phys_scaled.cpu().numpy())[:,0].flatten())
        all_preds_fbw_fixed_hp.extend(fbw_real_pred.cpu().numpy().flatten())
        all_true_fbw_fixed_hp.extend(train_data.y_phys_scaler.inverse_transform(by_phys_scaled.cpu().numpy())[:,1].flatten())
        all_preds_area_fixed_hp.extend(area_real_pred.cpu().numpy().flatten())
        all_true_area_fixed_hp.extend(train_data.y_phys_scaler.inverse_transform(by_phys_scaled.cpu().numpy())[:,2].flatten())

# Convert lists to numpy arrays for metric calculation
all_preds_fom_fixed_hp = np.array(all_preds_fom_fixed_hp)
all_true_fom_fixed_hp = np.array(all_true_fom_fixed_hp)
all_preds_eff_fixed_hp = np.array(all_preds_eff_fixed_hp)
all_true_eff_fixed_hp = np.array(all_true_eff_fixed_hp)
all_preds_fbw_fixed_hp = np.array(all_preds_fbw_fixed_hp)
all_true_fbw_fixed_hp = np.array(all_true_fbw_fixed_hp)
all_preds_area_fixed_hp = np.array(all_preds_area_fixed_hp)
all_true_area_fixed_hp = np.array(all_true_area_fixed_hp)

num_batches = len(test_loader)
avg_test_loss_eff_fixed_hp = test_loss_eff_fixed_hp / num_batches
avg_test_loss_fbw_fixed_hp = test_loss_fbw_fixed_hp / num_batches
avg_test_loss_area_fixed_hp = test_loss_area_fixed_hp / num_batches
avg_test_loss_fom_fixed_hp = test_loss_fom_fixed_hp / num_batches

final_test_loss_fixed_hp = avg_test_loss_eff_fixed_hp + avg_test_loss_fbw_fixed_hp + avg_test_loss_area_fixed_hp + avg_test_loss_fom_fixed_hp

print("\n--- Optimization and Evaluation Summary (Fixed HP) ---")
print(f"  Learning Rate: {FIXED_LR:.6f}")
print(f"  Hidden Dimension: {FIXED_HIDDEN_DIM}")
print(f"  Number of Residual Blocks: {FIXED_NUM_BLOCKS}")
print(f"Final Model Test Loss: {final_test_loss_fixed_hp:.4f}")

print("\n--- Individual Loss Contributions (Test Set, Fixed HP) ---")
print(f"  Efficiency Loss: {avg_test_loss_eff_fixed_hp:.4f} ({avg_test_loss_eff_fixed_hp/final_test_loss_fixed_hp*100:.2f}%)")
print(f"  FBW Loss: {avg_test_loss_fbw_fixed_hp:.4f} ({avg_test_loss_fbw_fixed_hp/final_test_loss_fixed_hp*100:.2f}%)")
print(f"  Area Loss: {avg_test_loss_area_fixed_hp:.4f} ({avg_test_loss_area_fixed_hp/final_test_loss_fixed_hp*100:.2f}%)")
print(f"  FoM Loss: {avg_test_loss_fom_fixed_hp:.4f} ({avg_test_loss_fom_fixed_hp/final_test_loss_fixed_hp*100:.2f}%)")

# Plotting the training and validation loss
plt.figure(figsize=(14, 10))
plt.plot(range(1, len(train_losses_fixed_hp) + 1), train_losses_fixed_hp, label='Training Loss', color='darkblue', linewidth=2)
plt.plot(range(1, len(val_losses_fixed_hp) + 1), val_losses_fixed_hp, label='Validation Loss', color='darkred', linewidth=2)
plt.xlabel('Epoch', fontsize=14, fontweight='bold')
plt.ylabel('Loss', fontsize=14, fontweight='bold')
plt.title('Training and Validation Loss Over Epochs', fontweight='bold')
plt.legend()
plt.grid(True)
plt.show()

# --- Quantitative Metrics (Accuracy) ---
print("\n--- Regression Metrics on Test Set (Unscaled Values, Fixed HP) ---")

mae_eff_fixed_hp = mean_absolute_error(all_true_eff_fixed_hp, all_preds_eff_fixed_hp)
r2_eff_fixed_hp = r2_score(all_true_eff_fixed_hp, all_preds_eff_fixed_hp)
print(f"  Efficiency (Avg_efficiency) - MAE: {mae_eff_fixed_hp:.4f}, R2: {r2_eff_fixed_hp:.4f}")

mae_fbw_fixed_hp = mean_absolute_error(all_true_fbw_fixed_hp, all_preds_fbw_fixed_hp)
r2_fbw_fixed_hp = r2_score(all_true_fbw_fixed_hp, all_preds_fbw_fixed_hp)
print(f"  FBW - MAE: {mae_fbw_fixed_hp:.4f}, R2: {r2_fbw_fixed_hp:.4f}")

mae_area_fixed_hp = mean_absolute_error(all_true_area_fixed_hp, all_preds_area_fixed_hp)
r2_area_fixed_hp = r2_score(all_true_area_fixed_hp, all_preds_area_fixed_hp)
print(f"  Total Area (mm^2) - MAE: {mae_area_fixed_hp:.4f}, R2: {r2_area_fixed_hp:.4f}")

mae_fom_fixed_hp = mean_absolute_error(all_true_fom_fixed_hp, all_preds_fom_fixed_hp)
r2_fom_fixed_hp = r2_score(all_true_fom_fixed_hp, all_preds_fom_fixed_hp)
print(f"  FoM (FoMt) - MAE: {mae_fom_fixed_hp:.4f}, R2: {r2_fom_fixed_hp:.4f}")

# --- Visualizations: Predicted vs. Actual (Fixed HP) ---
fig, axes = plt.subplots(2, 2, figsize=(14, 12))
fig.suptitle('Predicted vs. Actual Values on Test Set', fontsize=18, fontweight='bold')

# Plot Efficiency
axes[0, 0].scatter(all_true_eff_fixed_hp, all_preds_eff_fixed_hp, alpha=0.6)
min_val, max_val = min(all_true_eff_fixed_hp), max(all_true_eff_fixed_hp)
axes[0, 0].plot([min_val, max_val], [min_val, max_val], color='darkred', linestyle='--', linewidth=3)
axes[0, 0].set_title(f'Efficiency (MAE: {mae_eff_fixed_hp:.4f})')
axes[0, 0].set_xlabel('Actual Efficiency')
axes[0, 0].set_ylabel('Predicted Efficiency')
axes[0, 0].grid(True)

# Plot FBW
axes[0, 1].scatter(all_true_fbw_fixed_hp, all_preds_fbw_fixed_hp, alpha=0.6)
min_val, max_val = min(all_true_fbw_fixed_hp), max(all_true_fbw_fixed_hp)
axes[0, 1].plot([min_val, max_val], [min_val, max_val], color='darkred', linestyle='--', linewidth=3)
axes[0, 1].set_title(f'FBW (MAE: {mae_fbw_fixed_hp:.4f})')
axes[0, 1].set_xlabel('Actual FBW')
axes[0, 1].set_ylabel('Predicted FBW')
axes[0, 1].grid(True)

# Plot Area
axes[1, 0].scatter(all_true_area_fixed_hp, all_preds_area_fixed_hp, alpha=0.6)
min_val, max_val = min(all_true_area_fixed_hp), max(all_true_area_fixed_hp)
axes[1, 0].plot([min_val, max_val], [min_val, max_val], color='darkred', linestyle='--', linewidth=3)
axes[1, 0].set_title(f'Total Area (MAE: {mae_area_fixed_hp:.4f})')
axes[1, 0].set_xlabel('Actual Area')
axes[1, 0].set_ylabel('Predicted Area')
axes[1, 0].grid(True)

# Plot FoM
axes[1, 1].scatter(all_true_fom_fixed_hp, all_preds_fom_fixed_hp, alpha=0.6)
min_val, max_val = min(all_true_fom_fixed_hp), max(all_true_fom_fixed_hp)
axes[1, 1].plot([min_val, max_val], [min_val, max_val], color='darkred', linestyle='--', linewidth=3)
axes[1, 1].set_title(f'FoMT (MAE: {mae_fom_fixed_hp:.4f})')
axes[1, 1].set_xlabel('Actual FoMT')
axes[1, 1].set_ylabel('Predicted FoMT')
axes[1, 1].grid(True)

plt.tight_layout(rect=[0, 0.03, 1, 0.96])
plt.show()

# %%

import time
import torch

# Use the trained PI-ResNet
fixed_model.eval()

# Select one antenna geometry from the test dataset
sample_geometry = test_data.X_raw[0:1]

def predict_single_geometry():

    # Normalize antenna geometry
    scaled_input = train_data.scaler.transform(
        sample_geometry
    )

    # Convert normalized data to tensor
    input_tensor = torch.tensor(
        scaled_input,
        dtype=torch.float32,
        device=DEVICE
    )

    # Predict FoMT
    with torch.inference_mode():
        pred_fomt, _, _, _ = fixed_model(input_tensor)

    return pred_fomt.item()


# Warm-up predictions
for _ in range(50):
    predict_single_geometry()

if DEVICE.type == "cuda":
    torch.cuda.synchronize()

# Measure average inference time
n_runs = 500

start_time = time.perf_counter()

for _ in range(n_runs):
    predict_single_geometry()

if DEVICE.type == "cuda":
    torch.cuda.synchronize()

total_inference_time = time.perf_counter() - start_time

average_inference_time = total_inference_time / n_runs

print("\n--- PI-ResNet Inference Time ---")
print(f"Average inference time: {average_inference_time:.6f} seconds")
print(f"Average inference time: {average_inference_time*1000:.4f} milliseconds")


# %%
from torchsummary import summary

print("--- Final Model Architecture Summary ---")
# summary expects input_size to be a tuple representing (channels, height, width) or (features,) for linear models
summary(fixed_model, input_size=(INPUT_DIM,))

# %%
from scipy.optimize import differential_evolution
import numpy as np

# ==========================================
# PART 6: INVERSE DESIGN (OPTIMIZATION)
# ==========================================
print("\n--- Starting AI Inverse Design (Optimization) ---")
print("Searching for the optimal antenna dimensions to MAXIMIZE FoM...")

# 1. Define the Objective Function
# The optimizer gives us a list of raw parameters (Length, Width, etc.)
# We must Scale them -> Feed to AI -> Get FoM
def objective_function(design_params):
    # Ensure the model is in eval mode
    fixed_model.eval()

    # Reshape to (1, INPUT_DIM) because the model expects a batch
    design_params = design_params.reshape(1, -1)

    # SCALING: We must scale the input just like we did for training!
    # Corrected: Use train_data.scaler for X inputs
    scaled_params = train_data.scaler.transform(design_params)

    # Convert to Tensor
    input_tensor = torch.tensor(scaled_params, dtype=torch.float32).to(DEVICE)

    # Predict with the AI
    with torch.no_grad():
        # The model returns: fom, eff, fbw, area
        # We only care about the first output (fom) for optimization
        pred_fom, _, _, _ = fixed_model(input_tensor)

        # The model directly outputs real (unscaled) FoM, no further un-scaling needed for FoM
        fom_real = pred_fom.item()

    # OPTIMIZATION TRICK:
    # The solver tries to FIND the MINIMUM.
    # We want the MAXIMUM FoM.
    # So we return Negative FoM. (Minimizing -10 is the same as Maximizing +10)
    return -fom_real

# 2. Define the Bounds (Search Space)
# We need bounds for ALL INPUT_DIM inputs, matching the feature columns:
# ['Ant_length', 'Ant_width', 'patch_radius', 'inset_width', 'inset_length', 'mutual_gap']

# We automatically assume the search range is within the Min and Max of your training data
# so the AI doesn't hallucinate on data it has never seen.
min_vals = train_data.X_raw.min(axis=0)
max_vals = train_data.X_raw.max(axis=0)

# Create a list of (min, max) tuples for the INPUT_DIM features
bounds = []
for i in range(INPUT_DIM):
    # You can manually widen these if you want (e.g., min_vals[i]*0.9, max_vals[i]*1.1)
    bounds.append((min_vals[i], max_vals[i]))

# 3. Run the Genetic Algorithm
# strategies: 'best1bin' is standard. 'maxiter' is how long it thinks.
result = differential_evolution(
    objective_function,
    bounds,
    strategy='best1bin',
    maxiter=50,      # Increase this for better results (e.g., 100)
    popsize=15,      # Population size (15 * number of parameters)
    tol=0.01,
    disp=True        # Show progress
)

# 4. Display the Best Result
print("\n" + "="*40)
print("       OPTIMAL ANTENNA DESIGN FOUND       ")
print("="*40)
print(f"MAXIMUM Predicted FoM: {-result.fun:.4f} dB") # Remember to flip the sign back!

print("\nOptimal Dimensions (mm):")
# Feature names matching the INPUT_DIM
feature_names = [
    'Ant_length', 'Ant_width', 'patch_radius',
    'inset_width', 'inset_length', 'mutual_gap'
]

# Print neatly
for name, value in zip(feature_names, result.x):
    print(f"  {name:20s}: {value:.1f}")

print("\nSuggested Next Step: Simulate these dimensions in CST/HFSS to verify.")

# %%
print("--- Input Parameter Ranges (Min to Max) ---")
feature_names = [
    'Ant_length', 'Ant_width', 'patch_radius',
    'inset_width', 'inset_length', 'mutual_gap'
]

# min_vals and max_vals should be available from previous execution
if 'min_vals' in globals() and 'max_vals' in globals():
    for i, name in enumerate(feature_names):
        print(f"  {name:20s}: {min_vals[i]:.4f} to {max_vals[i]:.4f}")
else:
    print("Error: min_vals or max_vals not found. Please ensure the Inverse Design (Optimization) cell has been run.")

# %%
import numpy as np
import torch

print("\n--- Predict Physics Parameters for Optimized Dimensions ---")

# Use the optimal dimensions found by differential evolution
optimized_dimensions = np.array(result.x).reshape(1, -1)

# Scale the input parameters using the same scaler used for training
scaled_optimized_dimensions = train_data.scaler.transform(optimized_dimensions)

# Convert to PyTorch tensor and move to device
input_tensor_optimized = torch.tensor(
    scaled_optimized_dimensions, dtype=torch.float32
).to(DEVICE)

# Get predictions from the fixed_model
fixed_model.eval() # Ensure model is in evaluation mode
with torch.no_grad():
    pred_fom, pred_eff_scaled, pred_fbw_scaled, pred_area_scaled = fixed_model(
        input_tensor_optimized
    )

    # Un-scale physics predictions for human-readable values
    pred_eff_real = (
        pred_eff_scaled * fixed_model.phys_scale[0]
    ) + fixed_model.phys_mean[0]
    pred_fbw_real = (
        pred_fbw_scaled * fixed_model.phys_scale[1]
    ) + fixed_model.phys_mean[1]
    pred_area_real = (
        pred_area_scaled * fixed_model.phys_scale[2]
    ) + fixed_model.phys_mean[2]

print(f"Predicted FoM: {pred_fom.item():.4f} dB")
print(f"Predicted Efficiency: {pred_eff_real.item():.4f}")
print(f"Predicted FBW: {pred_fbw_real.item():.4f}")
print(f"Predicted Area: {pred_area_real.item():.4f} mm^2")

print("\nThese are the predicted performance characteristics for the optimized antenna design.")

# %%


# %% [markdown]
# # 7. MODEL COMPARISON: PIDL vs Other ML Models

# %%
# Get PIDL predictions on test set
fixed_model.eval()
pidl_predictions = []
pidl_phys_pred = {'eff': [], 'fbw': [], 'area': []}
y_test_actual = []
y_test_phys_actual = {'eff': [], 'fbw': [], 'area': []}

X_test_raw = []

with torch.no_grad():
    for bx, by_phys_scaled, by_fom_real in test_loader:
        bx = bx.to(DEVICE)
        by_phys_scaled = by_phys_scaled.to(DEVICE)
        by_fom_real = by_fom_real.to(DEVICE)
        
        # Get PIDL predictions
        pred_fom, pred_eff_scaled, pred_fbw_scaled, pred_area_scaled = fixed_model(bx)
        
        # Unscale physics predictions
        pred_eff_real = (pred_eff_scaled * fixed_model.phys_scale[0]) + fixed_model.phys_mean[0]
        pred_fbw_real = (pred_fbw_scaled * fixed_model.phys_scale[1]) + fixed_model.phys_mean[1]
        pred_area_real = (pred_area_scaled * fixed_model.phys_scale[2]) + fixed_model.phys_mean[2]
        
        pidl_predictions.extend(pred_fom.cpu().numpy().flatten())
        pidl_phys_pred['eff'].extend(pred_eff_real.cpu().numpy().flatten())
        pidl_phys_pred['fbw'].extend(pred_fbw_real.cpu().numpy().flatten())
        pidl_phys_pred['area'].extend(pred_area_real.cpu().numpy().flatten())
        
        y_test_actual.extend(by_fom_real.cpu().numpy().flatten())
        
        # Unscale actual physics values
        eff_actual = (by_phys_scaled[:, 0:1] * train_data.y_phys_scaler.scale_[0]) + train_data.y_phys_scaler.mean_[0]
        fbw_actual = (by_phys_scaled[:, 1:2] * train_data.y_phys_scaler.scale_[1]) + train_data.y_phys_scaler.mean_[1]
        area_actual = (by_phys_scaled[:, 2:3] * train_data.y_phys_scaler.scale_[2]) + train_data.y_phys_scaler.mean_[2]
        
        y_test_phys_actual['eff'].extend(eff_actual.cpu().numpy().flatten())
        y_test_phys_actual['fbw'].extend(fbw_actual.cpu().numpy().flatten())
        y_test_phys_actual['area'].extend(area_actual.cpu().numpy().flatten())
        
        X_test_raw.extend(bx.cpu().numpy())

pidl_predictions = np.array(pidl_predictions)
y_test_actual = np.array(y_test_actual)
X_test_raw = np.array(X_test_raw)

print(f"PI-ResNet Predictions Shape: {pidl_predictions.shape}")
print(f"Test Actual Shape: {y_test_actual.shape}")
print(f"Test Features Shape: {X_test_raw.shape}")

# %%
# Prepare training data for traditional ML models
X_train_np = np.array([train_data[i][0] for i in range(len(train_data))])
y_train_np = np.array([train_data[i][2].item() for i in range(len(train_data))])

X_test_np = X_test_raw
y_test_np = y_test_actual

print(f"X_train shape: {X_train_np.shape}, y_train shape: {y_train_np.shape}")
print(f"X_test shape: {X_test_np.shape}, y_test shape: {y_test_np.shape}")

# %%
from sklearn.linear_model import Ridge, LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import time

print("\n" + "="*80)
print("TRAINING TRADITIONAL ML MODELS FOR COMPARISON")
print("="*80 + "\n")

# Dictionary to store models and predictions
models = {}
predictions = {}
train_times = {}
metrics = {}

# 1. RIDGE REGRESSION
print("1. Training Ridge Regression...")
start = time.time()
models['Ridge'] = Ridge(alpha=1.0)
models['Ridge'].fit(X_train_np, y_train_np)
train_times['Ridge'] = time.time() - start
predictions['Ridge'] = models['Ridge'].predict(X_test_np)
print(f"   ✓ Trained in {train_times['Ridge']:.4f}s")

# 2. RANDOM FOREST
print("2. Training Random Forest...")
start = time.time()
models['RF'] = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
models['RF'].fit(X_train_np, y_train_np)
train_times['RF'] = time.time() - start
predictions['RF'] = models['RF'].predict(X_test_np)
print(f"   ✓ Trained in {train_times['RF']:.4f}s")

# 3. GRADIENT BOOSTING
print("3. Training Gradient Boosting...")
start = time.time()
models['GB'] = GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, max_depth=3, random_state=42)
models['GB'].fit(X_train_np, y_train_np)
train_times['GB'] = time.time() - start
predictions['GB'] = models['GB'].predict(X_test_np)
print(f"   ✓ Trained in {train_times['GB']:.4f}s")

# 4. SUPPORT VECTOR REGRESSOR
print("4. Training Support Vector Regressor...")
start = time.time()
models['SVR'] = SVR(kernel='rbf', C=100, epsilon=0.01)
models['SVR'].fit(X_train_np, y_train_np)
train_times['SVR'] = time.time() - start
predictions['SVR'] = models['SVR'].predict(X_test_np)
print(f"   ✓ Trained in {train_times['SVR']:.4f}s")

# 5. LINEAR REGRESSION
print("5. Training Linear Regression...")
start = time.time()
models['Linear'] = LinearRegression()
models['Linear'].fit(X_train_np, y_train_np)
train_times['Linear'] = time.time() - start
predictions['Linear'] = models['Linear'].predict(X_test_np)
print(f"   ✓ Trained in {train_times['Linear']:.4f}s")

# Add PI-ResNet predictions
predictions['PI-ResNet'] = pidl_predictions

print("\n✓ All models trained successfully!")
print(f"Total training time: {sum(train_times.values()):.4f}s")

# %%
print("\n" + "="*80)
print("CALCULATING PERFORMANCE METRICS FOR ALL MODELS")
print("="*80 + "\n")

# Calculate metrics for all models
for model_name, y_pred in predictions.items():
    mae = mean_absolute_error(y_test_np, y_pred)
    mse = mean_squared_error(y_test_np, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test_np, y_pred)
    mape = np.mean(np.abs((y_test_np - y_pred) / (y_test_np + 1e-8))) * 100
    
    metrics[model_name] = {
        'MAE': mae,
        'MSE': mse,
        'RMSE': rmse,
        'R²': r2,
        'MAPE': mape
    }
    
    print(f"\n{model_name}:")
    print(f"  MAE:   {mae:.8f}")
    print(f"  MSE:   {mse:.12f}")
    print(f"  RMSE:  {rmse:.8f}")
    print(f"  R²:    {r2:.8f}")
    print(f"  MAPE:  {mape:.4f}%")

# Create comparison DataFrame
comparison_df = pd.DataFrame(metrics).T
comparison_df = comparison_df[['MAE', 'MSE', 'RMSE', 'R²', 'MAPE']]

print("\n" + "="*80)
print("MODEL COMPARISON TABLE")
print("="*80)
print(comparison_df.to_string())
print("="*80)

# %%
import matplotlib.pyplot as plt
import seaborn as sns

# Set style
sns.set_style("whitegrid")

# Use a high-contrast palette so each model is easy to distinguish
model_palette = ['#0B3C5D', '#D1495B', '#F4A261', '#2A9D8F', '#6D597A', '#E76F51']

# Create comprehensive comparison plots
fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.patch.set_facecolor('white')

model_names = list(metrics.keys())
colors = model_palette[:len(model_names)]

# 1. MAE Comparison
ax = axes[0, 0]
mae_values = [metrics[m]['MAE'] for m in model_names]
bars = ax.bar(model_names, mae_values, color=colors, edgecolor='black', linewidth=1.5)
ax.set_title('Mean Absolute Error (MAE)\n(Lower is Better)', fontweight='bold', fontsize=12)
ax.set_ylabel('MAE', fontsize=11)
ax.tick_params(axis='x', rotation=45)
for i, (bar, val) in enumerate(zip(bars, mae_values)):
    ax.text(bar.get_x() + bar.get_width()/2, val, f'{val:.2e}', ha='center', va='bottom', fontsize=12, fontweight='bold')

# 2. MSE Comparison
ax = axes[0, 1]
mse_values = [metrics[m]['MSE'] for m in model_names]
bars = ax.bar(model_names, mse_values, color=colors, edgecolor='black', linewidth=1.5)
ax.set_title('Mean Squared Error (MSE)\n(Lower is Better)', fontweight='bold', fontsize=12)
ax.set_ylabel('MSE', fontsize=11)
ax.tick_params(axis='x', rotation=45)
for i, (bar, val) in enumerate(zip(bars, mse_values)):
    ax.text(bar.get_x() + bar.get_width()/2, val, f'{val:.2e}', ha='center', va='bottom', fontsize=12, fontweight='bold')

# 3. RMSE Comparison
ax = axes[1, 0]
rmse_values = [metrics[m]['RMSE'] for m in model_names]
bars = ax.bar(model_names, rmse_values, color=colors, edgecolor='black', linewidth=1.5)
ax.set_title('Root Mean Squared Error (RMSE)\n(Lower is Better)', fontweight='bold', fontsize=12)
ax.set_ylabel('RMSE', fontsize=11)
ax.tick_params(axis='x', rotation=45)
for i, (bar, val) in enumerate(zip(bars, rmse_values)):
    ax.text(bar.get_x() + bar.get_width()/2, val, f'{val:.2e}', ha='center', va='bottom', fontsize=12, fontweight='bold')

# 4. R² Comparison
ax = axes[1, 1]
r2_values = [metrics[m]['R²'] for m in model_names]
bars = ax.bar(model_names, r2_values, color=colors, edgecolor='black', linewidth=1.5)
ax.set_title('R² Score (Accuracy)\n(Higher is Better)', fontweight='bold', fontsize=12)
ax.set_ylabel('R² Score', fontsize=11)
ax.set_ylim([min(r2_values) * 0.95, 1.01])
ax.tick_params(axis='x', rotation=45)
for i, (bar, val) in enumerate(zip(bars, r2_values)):
    ax.text(bar.get_x() + bar.get_width()/2, val, f'{val:.4f}', ha='center', va='bottom', fontsize=12, fontweight='bold')

plt.tight_layout()
plt.show()

print("✓ Comparison plots generated")

# %%
import matplotlib.pyplot as plt
import seaborn as sns

# Set global font configuration for Times New Roman and bold text
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['font.weight'] = 'bold'
plt.rcParams['axes.labelweight'] = 'bold'
plt.rcParams['axes.titleweight'] = 'bold'

# Set style
sns.set_style("whitegrid")

# Use a high-contrast palette so each model is easy to distinguish
model_palette = ['#0B3C5D', '#D1495B', '#F4A261', '#2A9D8F', '#6D597A', '#E76F51']

# Create comprehensive comparison plots
fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.patch.set_facecolor('white')

# Recalculate metrics if the metrics cell was not executed
if not metrics:
    for model_name, y_pred in predictions.items():
        mse = mean_squared_error(y_test_np, y_pred)
        metrics[model_name] = {
            'MAE': mean_absolute_error(y_test_np, y_pred),
            'MSE': mse,
            'RMSE': np.sqrt(mse),
            'R²': r2_score(y_test_np, y_pred),
            'MAPE': np.mean(
                np.abs((y_test_np - y_pred) / (y_test_np + 1e-8))
            ) * 100
        }

model_names = list(metrics.keys())
colors = model_palette[:len(model_names)]

# 1. MAE Comparison
ax = axes[0, 0]
mae_values = [metrics[m]['MAE'] for m in model_names]
bars = ax.bar(model_names, mae_values, color=colors, edgecolor='black', linewidth=1.5)
ax.set_title('Mean Absolute Error (MAE)\n(Lower is Better)', fontweight='bold', fontsize=12, fontname='Times New Roman')
ax.set_ylabel('MAE', fontweight='bold', fontsize=11, fontname='Times New Roman')
for label in ax.get_xticklabels() + ax.get_yticklabels():
    label.set_fontname('Times New Roman')
    label.set_fontweight('bold')
ax.tick_params(axis='x', rotation=45)
for i, (bar, val) in enumerate(zip(bars, mae_values)):
    ax.text(bar.get_x() + bar.get_width()/2, val, f'{val:.4f}', ha='center', va='bottom', fontsize=12, fontweight='bold', fontname='Times New Roman')

# 2. MSE Comparison
ax = axes[0, 1]
mse_values = [metrics[m]['MSE'] for m in model_names]
bars = ax.bar(model_names, mse_values, color=colors, edgecolor='black', linewidth=1.5)
ax.set_title('Mean Squared Error (MSE)\n(Lower is Better)', fontweight='bold', fontsize=12, fontname='Times New Roman')
ax.set_ylabel('MSE', fontweight='bold', fontsize=11, fontname='Times New Roman')
for label in ax.get_xticklabels() + ax.get_yticklabels():
    label.set_fontname('Times New Roman')
    label.set_fontweight('bold')
ax.tick_params(axis='x', rotation=45)
for i, (bar, val) in enumerate(zip(bars, mse_values)):
    ax.text(bar.get_x() + bar.get_width()/2, val, f'{val:.4f}', ha='center', va='bottom', fontsize=12, fontweight='bold', fontname='Times New Roman')

# 3. RMSE Comparison
ax = axes[1, 0]
rmse_values = [metrics[m]['RMSE'] for m in model_names]
bars = ax.bar(model_names, rmse_values, color=colors, edgecolor='black', linewidth=1.5)
ax.set_title('Root Mean Squared Error (RMSE)\n(Lower is Better)', fontweight='bold', fontsize=12, fontname='Times New Roman')
ax.set_ylabel('RMSE', fontweight='bold', fontsize=11, fontname='Times New Roman')
for label in ax.get_xticklabels() + ax.get_yticklabels():
    label.set_fontname('Times New Roman')
    label.set_fontweight('bold')
ax.tick_params(axis='x', rotation=45)
for i, (bar, val) in enumerate(zip(bars, rmse_values)):
    ax.text(bar.get_x() + bar.get_width()/2, val, f'{val:.4f}', ha='center', va='bottom', fontsize=12, fontweight='bold', fontname='Times New Roman')

# 4. R² Comparison
ax = axes[1, 1]
r2_values = [metrics[m]['R²'] for m in model_names]
bars = ax.bar(model_names, r2_values, color=colors, edgecolor='black', linewidth=1.5)
ax.set_title('R² Score (Accuracy)\n(Higher is Better)', fontweight='bold', fontsize=12, fontname='Times New Roman')
ax.set_ylabel('R² Score', fontweight='bold', fontsize=11, fontname='Times New Roman')
ax.set_ylim([min(r2_values) * 0.95, 1.01])
for label in ax.get_xticklabels() + ax.get_yticklabels():
    label.set_fontname('Times New Roman')
    label.set_fontweight('bold')
ax.tick_params(axis='x', rotation=45)
for i, (bar, val) in enumerate(zip(bars, r2_values)):
    ax.text(bar.get_x() + bar.get_width()/2, val, f'{val:.4f}', ha='center', va='bottom', fontsize=12, fontweight='bold', fontname='Times New Roman')

plt.tight_layout()
plt.show()

print("✓ Comparison plots generated")

# %%
import matplotlib.pyplot as plt
import numpy as np
# ==========================================
# JOURNAL PLOT CONFIGURATION (EDIT HERE)
# ==========================================
# Use 'Dark2', 'tab10', or 'Set2' for high-contrast, paper-ready colors
cmap = plt.cm.Dark2  

# Scatter plot styling
MARKER_SIZE = 35       # Size of the data points
MARKER_ALPHA = 0.65    # Opacity (lower this to 0.2 or 0.3 if you have heavy data overlap)

# Reference line styling (Deep crimson/rust is more legible in print than bright red)
REF_LINE_COLOR = '#b2182b' 
REF_LINE_STYLE = '--'
REF_LINE_WIDTH = 2.0

# Prediction vs Actual plots for each model
fig, axes = plt.subplots(2, 3, figsize=(18, 10))
axes = axes.flatten()

model_names_sorted = sorted(model_names, key=lambda x: metrics[x]['R²'], reverse=True)

for idx, model_name in enumerate(model_names_sorted):
    ax = axes[idx]
    y_pred = predictions[model_name]
    
    # Scatter plot
    ax.scatter(y_test_np, y_pred, alpha=MARKER_ALPHA, s=MARKER_SIZE, color=colors[list(model_names).index(model_name)])
    
    # Perfect prediction line
    min_val = min(y_test_np.min(), y_pred.min())
    max_val = max(y_test_np.max(), y_pred.max())
    ax.plot([min_val, max_val], [min_val, max_val], 'r--', lw=2, label='Perfect Prediction')
    
    ax.set_xlabel('Actual FoM', fontsize=11)
    ax.set_ylabel('Predicted FoM', fontsize=11)
    ax.set_title(f'{model_name}\nR² = {metrics[model_name]["R²"]:.6f}', fontweight='bold', fontsize=12)
    ax.legend()
    ax.grid(True, alpha=0.3)

# Hide the last subplot if odd number of models
if len(model_names_sorted) < len(axes):
    axes[-1].set_visible(False)

plt.tight_layout()
plt.show()

print("✓ Prediction vs Actual plots generated")

# %%
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman'] + plt.rcParams['font.serif']
plt.rcParams['mathtext.fontset'] = 'stix'  # Makes LaTeX equations match Times New Roman style

# ==========================================
# JOURNAL PLOT CONFIGURATION (EDIT HERE)
# ==========================================
# Use 'Dark2', 'tab10', or 'Set2' for high-contrast, paper-ready colors
cmap = plt.cm.tab10  # 'tab10' is a good choice for up to 10 distinct colors  

# Scatter plot styling
MARKER_SIZE = 35       # Size of the data points
MARKER_ALPHA = 0.65    # Opacity (lower this to 0.2 or 0.3 if you have heavy data overlap)

# Reference line styling (Deep crimson/rust is more legible in print than bright red)
REF_LINE_COLOR = '#b2182b' 
REF_LINE_STYLE = '--'
REF_LINE_WIDTH = 2.0

# ==========================================
# PLOTTING LOGIC
# ==========================================
fig, axes = plt.subplots(2, 3, figsize=(18, 10))
axes = axes.flatten()

# Sort models by R² score descending
model_names_sorted = sorted(model_names, key=lambda x: metrics[x]['R²'], reverse=True)

for idx, model_name in enumerate(model_names_sorted):
    ax = axes[idx]
    y_pred = predictions[model_name]
    
    # Dynamically assign a clean, high-contrast color from the palette
    plot_color = cmap(idx % 8) 
    
    # Scatter plot of actual vs predicted values
    ax.scatter(y_test_np, y_pred, 
               alpha=MARKER_ALPHA, 
               s=MARKER_SIZE, 
               color=plot_color, 
               edgecolors='none') # Removes borders around dots for a cleaner look
    
    # Perfect prediction identity line (y = x)
    min_val = min(y_test_np.min(), y_pred.min())
    max_val = max(y_test_np.max(), y_pred.max())
    ax.plot([min_val, max_val], [min_val, max_val], 
            color=REF_LINE_COLOR, 
            linestyle=REF_LINE_STYLE, 
            lw=REF_LINE_WIDTH, 
            label='Perfect Prediction')
    
    # Labels and Titles
    ax.set_xlabel('Actual FoMT', fontsize=12, fontweight='bold', labelpad=8)
    ax.set_ylabel('Predicted FoMT', fontsize=12, fontweight='bold', labelpad=8)
    ax.set_title(f'{model_name}\n$R^2 = {metrics[model_name]["R²"]:.4f}$', 
                 fontweight='bold', 
                 fontsize=13, 
                 pad=10)
    
    # Legend & Grid
    ax.legend(loc='upper left', frameon=True, facecolor='white', edgecolor='none', fontsize=10)
    ax.grid(True, linestyle=':', alpha=0.5, color='#888888') # Subtle dotted grid lines

# Clean up: Hide any unused subplots safely
for i in range(len(model_names_sorted), len(axes)):
    axes[i].set_visible(False)

plt.tight_layout()
plt.show()

print("✓ High-visibility Prediction vs Actual plots generated successfully.")

# %%
# Residual Analysis - Error Distribution for each model
fig, axes = plt.subplots(2, 3, figsize=(18, 10))
axes = axes.flatten()

for idx, model_name in enumerate(model_names_sorted):
    ax = axes[idx]
    y_pred = predictions[model_name]
    residuals = y_test_np - y_pred
    
    ax.scatter(y_pred, residuals, alpha=0.6, s=30, color=colors[list(model_names).index(model_name)])
    ax.axhline(y=0, color='r', linestyle='--', lw=2)
    
    ax.set_xlabel('Predicted FoM', fontsize=11)
    ax.set_ylabel('Residual (Actual - Predicted)', fontsize=11)
    ax.set_title(f'{model_name} - Residual Plot\nStd Dev: {np.std(residuals):.4f}', fontweight='bold', fontsize=12)
    ax.grid(True, alpha=0.3)

# Hide the last subplot if odd number of models
if len(model_names_sorted) < len(axes):
    axes[-1].set_visible(False)

plt.tight_layout()
plt.show()

print("✓ Residual plots generated")

# %%
import matplotlib.pyplot as plt
import numpy as np

# 1. Set global font to Times New Roman
plt.rcParams['font.family'] = 'Times New Roman'

# 2. Define a list of highly distinct, high-contrast colors (up to 6 for the 2x3 grid)
# Colors: Blue, Green, Red, Purple, Orange, Cyan
distinct_colors = ['#1f77b4', '#2ca02c', '#d62728', '#9467bd', '#ff7f0e', '#17becf']

# Residual Analysis - Error Distribution for each model
fig, axes = plt.subplots(2, 3, figsize=(18, 10))
axes = axes.flatten()

for idx, model_name in enumerate(model_names_sorted):
    ax = axes[idx]
    y_pred = predictions[model_name]
    residuals = y_test_np - y_pred
    
    # Select distinct color based on the current index
    plot_color = distinct_colors[idx % len(distinct_colors)]
    
    # Added edgecolor='k' (black border) to make the points stand out clearly
    ax.scatter(y_pred, residuals, alpha=0.7, s=40, color=plot_color, edgecolor='k', linewidth=0.5)
    
    # Changed the horizontal line to black to ensure it doesn't clash with red scatter dots
    ax.axhline(y=0, color='black', linestyle='--', lw=2)
    
    ax.set_xlabel('Predicted FoM', fontsize=12)
    ax.set_ylabel('Residual (Actual - Predicted)', fontsize=12)
    ax.set_title(f'{model_name} - Residual Plot\nStd Dev: {np.std(residuals):.4f}', fontweight='bold', fontsize=14)
    ax.grid(True, alpha=0.3)

# Hide any remaining empty subplots safely (works if there are 4, 5, or fewer models)
for i in range(len(model_names_sorted), len(axes)):
    axes[i].set_visible(False)

plt.tight_layout()
plt.show()

print("✓ Residual plots generated")


