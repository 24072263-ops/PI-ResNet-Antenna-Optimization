# %%
# %pip install numpy pandas openpyxl torch scikit-learn matplotlib ipykernel

# %%
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
import math
import random

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import Dataset, DataLoader
from IPython.display import display, Image

FEATURES = ["Ant_length", "Ant_width", "patch_radius", "inset_width", "inset_length", "mutual_gap"]
PHYSICS_TARGETS = ["Avg_efficiency", "FBW", "Total Area (mm^2)"]
TARGET = "FoMt"
WAVELENGTH = 241.12  
THETA_R = 6.283
SEED = 42
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
DATA_PATH = Path("final_sorted_dataset.xlsx") 
OUTPUT_DIR = Path("reviewer1_holdout_results")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
results = {}  # Completed full experiments (kept between training cells)

@dataclass
class Config:
    hidden_dim: int = 412
    num_blocks: int = 3
    learning_rate: float = 0.007767
    batch_size: int = 32
    max_epochs: int = 200
    patience: int = 20
    huber_delta: float = 1.0

def set_seed(seed: int = SEED) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

print('PyTorch version:', torch.__version__)
print('Selected device:', DEVICE)
print('Data path:', DATA_PATH.resolve())
print('Output directory:', OUTPUT_DIR.resolve())

# %%
if not DATA_PATH.is_file():
    raise FileNotFoundError(
        f'Could not find {DATA_PATH.resolve()}. Place the Excel file beside the notebook '
        'or update DATA_PATH in Block 2.'
    )

df = pd.read_excel(DATA_PATH)
required_cols = FEATURES + PHYSICS_TARGETS + [TARGET]
missing_cols = [col for col in required_cols if col not in df.columns]
if missing_cols:
    raise ValueError(f'Missing columns: {missing_cols}. Available: {df.columns.tolist()}')
if df[required_cols].isna().any().any():
    raise ValueError('Dataset contains missing values in required input or output columns.')
if df[FEATURES].duplicated().any():
    raise ValueError('Duplicate antenna geometry input configurations found.')

print('Number of antenna geometries:', len(df))
print('\nColumns:', df.columns.tolist())
print('\nAvailable patch-radius levels:', sorted(df['patch_radius'].unique()))
print('Available mutual-gap levels:', sorted(df['mutual_gap'].unique()))
display(df[required_cols].head())

# %%
def get_split(df: pd.DataFrame, kind: str):
    """Entire geometry PARAMETER LEVELS are withheld from model training."""
    if kind == "random_70_15_15":
        train, temporary = train_test_split(df, test_size=0.30, random_state=SEED, shuffle=True)
        valid, test = train_test_split(temporary, test_size=0.50, random_state=SEED, shuffle=True)
    elif kind in ("radius_holdout", "gap_holdout"):
        col, valid_level, test_level = (
            ("patch_radius", 50.0, 45.0) if kind == "radius_holdout"
            else ("mutual_gap", 1.5, 1.0)
        )
        valid_mask = np.isclose(df[col].to_numpy(dtype=float), valid_level)
        test_mask = np.isclose(df[col].to_numpy(dtype=float), test_level)
        train = df.loc[~(valid_mask | test_mask)]
        valid = df.loc[valid_mask]
        test = df.loc[test_mask]
        assert not np.isclose(train[col], valid_level).any()
        assert not np.isclose(train[col], test_level).any()
    else:
        raise ValueError(f"Unknown split kind: {kind}")

    # All three subsets use distinct original rows.
    tr_ids, val_ids, te_ids = set(train.index), set(valid.index), set(test.index)
    assert tr_ids.isdisjoint(val_ids) and tr_ids.isdisjoint(te_ids) and val_ids.isdisjoint(te_ids)
    assert len(tr_ids | val_ids | te_ids) == len(df)
    assert min(map(len, (train, valid, test))) > 0
    return train.copy(), valid.copy(), test.copy()

for method_name in ["random_70_15_15", "radius_holdout", "gap_holdout"]:
    tr, va, te = get_split(df, method_name)
    print(f"{method_name:18}  Train={len(tr):4} | Validation={len(va):4} | Test={len(te):4}")

# %%
class AntennaDataset(Dataset):
    """Matches the dataset processing in the user's notebook; fits on TRAIN only."""
    def __init__(self, frame: pd.DataFrame, input_scaler=None, physics_scaler=None):
        self.original_frame = frame.copy().reset_index(drop=True)
        x_raw = frame[FEATURES].to_numpy(dtype=np.float32)
        phys_raw = frame[PHYSICS_TARGETS].to_numpy(dtype=np.float32)
        fom_raw = frame[[TARGET]].to_numpy(dtype=np.float32)

        self.scaler = StandardScaler() if input_scaler is None else input_scaler
        self.y_phys_scaler = StandardScaler() if physics_scaler is None else physics_scaler
        if input_scaler is None:
            self.X = self.scaler.fit_transform(x_raw).astype(np.float32)
        else:
            self.X = self.scaler.transform(x_raw).astype(np.float32)
        if physics_scaler is None:
            self.y_physics = self.y_phys_scaler.fit_transform(phys_raw).astype(np.float32)
        else:
            self.y_physics = self.y_phys_scaler.transform(phys_raw).astype(np.float32)
        self.y_fom = fom_raw

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y_physics[idx], self.y_fom[idx]

# %%
class ResidualBlock(nn.Module):
    """Identical layers and dropout rate to final_code.ipynb."""
    def __init__(self, hidden_dim: int, dropout_rate: float = 0.3):
        super().__init__()
        self.block = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim), nn.BatchNorm1d(hidden_dim),
            nn.ReLU(), nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim, hidden_dim), nn.BatchNorm1d(hidden_dim),
        )
        self.activation = nn.ReLU()

    def forward(self, x):
        return self.activation(x + self.block(x))


class FoMEquationLayer(nn.Module):
    """Same physics equation as the uploaded model, using device-safe log10."""
    def __init__(self, wavelength: float, theta_r: float):
        super().__init__()
        self.wavelength = wavelength
        self.theta_r = theta_r
        self.register_buffer("pi", torch.tensor(math.pi, dtype=torch.float32))

    def forward(self, efficiency, fbw, area):
        denominator = (4 * self.pi * area) / (self.theta_r * self.wavelength**2)
        ratio = (efficiency * fbw) / (denominator + 1e-8)
        return 10.0 * torch.log10(ratio + 1e-8)


class AdvancedPIDLModel(nn.Module):
    """Three heads retained, including the antenna-area head (Reviewer 1 comment 1)."""
    def __init__(self, input_dim: int, phys_scaler: StandardScaler,
                 hidden_dim: int = 412, num_blocks: int = 3):
        super().__init__()
        self.input_layer = nn.Sequential(nn.Linear(input_dim, hidden_dim), nn.ReLU())
        self.backbone = nn.Sequential(*[ResidualBlock(hidden_dim) for _ in range(num_blocks)])
        self.register_buffer("phys_mean", torch.tensor(phys_scaler.mean_, dtype=torch.float32))
        self.register_buffer("phys_scale", torch.tensor(phys_scaler.scale_, dtype=torch.float32))
        self.head_eff = nn.Linear(hidden_dim, 1)
        self.head_fbw = nn.Linear(hidden_dim, 1)
        self.head_area = nn.Linear(hidden_dim, 1)
        self.physics_layer = FoMEquationLayer(WAVELENGTH, THETA_R)

    def forward(self, x):
        features = self.backbone(self.input_layer(x))
        e_scaled = self.head_eff(features)
        f_scaled = self.head_fbw(features)
        a_scaled = self.head_area(features)
        eff = torch.relu(e_scaled * self.phys_scale[0] + self.phys_mean[0]) + 1e-6
        fbw = torch.relu(f_scaled * self.phys_scale[1] + self.phys_mean[1]) + 1e-6
        area = torch.relu(a_scaled * self.phys_scale[2] + self.phys_mean[2]) + 1e-6
        fom = self.physics_layer(eff, fbw, area)
        return fom, e_scaled, f_scaled, a_scaled

# %%
def summed_huber_loss(model, batch, loss_function):
    bx, by_phys, by_fom = (x.to(DEVICE) for x in batch)
    predicted_fom, pred_e, pred_f, pred_a = model(bx)
    return (loss_function(predicted_fom, by_fom)
            + loss_function(pred_e, by_phys[:, 0:1])
            + loss_function(pred_f, by_phys[:, 1:2])
            + loss_function(pred_a, by_phys[:, 2:3]))


def metric_dict(actual, predicted):
    return {
        "R2": float(r2_score(actual, predicted)),
        "MAE": float(mean_absolute_error(actual, predicted)),
        "MSE": float(mean_squared_error(actual, predicted)),
        "RMSE": float(np.sqrt(mean_squared_error(actual, predicted))),
    }

# %%
def plot_learning_curve(history: list[dict], experiment: str, output_dir: Path):
    history_df = pd.DataFrame(history)
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(history_df["epoch"], history_df["train_loss"], label="Training")
    ax.plot(history_df["epoch"], history_df["val_loss"], label="Validation")
    ax.set(xlabel="Epoch", ylabel="Mean multitask Huber loss", title=f"Learning curve: {experiment}")
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_dir / f"{experiment}_learning_curve.png", dpi=220)
    plt.close(fig)
    history_df.to_csv(output_dir / f"{experiment}_learning_curve.csv", index=False)


def plot_parity(actual, predicted, experiment: str, output_dir: Path, r2: float):
    fig, ax = plt.subplots(figsize=(5, 5))
    ax.scatter(actual, predicted, alpha=0.35, s=12)
    bounds = [float(min(actual.min(), predicted.min())), float(max(actual.max(), predicted.max()))]
    ax.plot(bounds, bounds, linestyle="--", linewidth=1.2, label="Perfect prediction")
    ax.set(xlabel="Simulated FoMT (dB)", ylabel="Predicted FoMT (dB)",
           title=f"{experiment} | Test R²={r2:.4f}")
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_dir / f"{experiment}_fomt_parity.png", dpi=220)
    plt.close(fig)

# %%
def run_experiment(df: pd.DataFrame, experiment: str, conf: Config,
                   output_dir: Path, quick_check: bool = False):
    set_seed(SEED)       # The SAME initialization seed for every split.
    train_frame, val_frame, test_frame = get_split(df, experiment)
    print(f"\n[{experiment}] TRAIN={len(train_frame)}, VAL={len(val_frame)}, TEST={len(test_frame)}", flush=True)

    train_ds = AntennaDataset(train_frame)  # fit scalers on training ONLY
    val_ds = AntennaDataset(val_frame, train_ds.scaler, train_ds.y_phys_scaler)
    test_ds = AntennaDataset(test_frame, train_ds.scaler, train_ds.y_phys_scaler)
    batch_generator = torch.Generator().manual_seed(SEED)
    train_loader = DataLoader(train_ds, batch_size=conf.batch_size, shuffle=True, generator=batch_generator)
    val_loader = DataLoader(val_ds, batch_size=conf.batch_size, shuffle=False)
    test_loader = DataLoader(test_ds, batch_size=conf.batch_size, shuffle=False)

    model = AdvancedPIDLModel(len(FEATURES), train_ds.y_phys_scaler,
                              conf.hidden_dim, conf.num_blocks).to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=conf.learning_rate)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="min", factor=0.5, patience=5)
    loss_fn = nn.HuberLoss(delta=conf.huber_delta)

    best_val_loss, best_epoch, best_state, stalled = float("inf"), 0, None, 0
    history = []
    for epoch in range(1, conf.max_epochs + 1):
        model.train()
        train_total = 0.0
        for batch in train_loader:
            optimizer.zero_grad(set_to_none=True)
            loss = summed_huber_loss(model, batch, loss_fn)
            loss.backward()
            optimizer.step()
            train_total += loss.item()
        mean_train = train_total / len(train_loader)

        model.eval()
        with torch.inference_mode():
            val_total = sum(summed_huber_loss(model, batch, loss_fn).item() for batch in val_loader)
        mean_val = val_total / len(val_loader)
        scheduler.step(mean_val)
        history.append({"epoch": epoch, "train_loss": mean_train, "val_loss": mean_val})
        if mean_val < best_val_loss:
            best_val_loss, best_epoch = mean_val, epoch
            best_state = deepcopy(model.state_dict())  # FIX: snapshot, not a mutable reference
            stalled = 0
        else:
            stalled += 1
        if epoch == 1 or epoch % 10 == 0:
            print(f"  epoch {epoch:3d}: train={mean_train:.5f} val={mean_val:.5f} best_epoch={best_epoch}", flush=True)
        if stalled >= conf.patience:
            print(f"  early stopping at epoch {epoch}", flush=True)
            break
    assert best_state is not None
    model.load_state_dict(best_state)
    model.eval()

    actual_fomt, pred_fomt = [], []
    actual_phys, pred_phys = [], []
    with torch.inference_mode():
        for batch in test_loader:
            bx, by_phys, by_fom = (x.to(DEVICE) for x in batch)
            pfom, pe, pf, pa = model(bx)
            actual_fomt.append(by_fom.cpu().numpy().reshape(-1))
            pred_fomt.append(pfom.cpu().numpy().reshape(-1))
            actual_phys.append(by_phys.cpu().numpy())
            pred_phys.append(torch.cat((pe, pf, pa), dim=1).cpu().numpy())
    actual_fomt = np.concatenate(actual_fomt)
    pred_fomt = np.concatenate(pred_fomt)
    actual_phys = train_ds.y_phys_scaler.inverse_transform(np.concatenate(actual_phys))
    pred_phys = train_ds.y_phys_scaler.inverse_transform(np.concatenate(pred_phys))

    # Test performance is evaluated ONCE, after validation-selected checkpoint is loaded.
    metrics = metric_dict(actual_fomt, pred_fomt)
    result = {"method": experiment, "train_n": len(train_ds), "val_n": len(val_ds),
              "test_n": len(test_ds), "best_epoch": best_epoch,
              "best_validation_loss": best_val_loss, **metrics}
    print(f"  FoMT test metrics: {metrics}", flush=True)

    if not quick_check:
        plot_learning_curve(history, experiment, output_dir)
        plot_parity(actual_fomt, pred_fomt, experiment, output_dir, metrics["R2"])
        prediction_file = test_frame[FEATURES].reset_index(drop=True).copy()
        prediction_file["actual_FoMt"] = actual_fomt
        prediction_file["predicted_FoMt"] = pred_fomt
        for i, col in enumerate(PHYSICS_TARGETS):
            prediction_file[f"actual_{col}"] = actual_phys[:, i]
            prediction_file[f"predicted_{col}"] = pred_phys[:, i]
        prediction_file.to_csv(output_dir / f"{experiment}_test_predictions.csv", index=False)
        torch.save({"model_state_dict": model.cpu().state_dict(),
                    "input_scaler_mean": train_ds.scaler.mean_,
                    "input_scaler_scale": train_ds.scaler.scale_,
                    "physics_scaler_mean": train_ds.y_phys_scaler.mean_,
                    "physics_scaler_scale": train_ds.y_phys_scaler.scale_,
                    "split": experiment, "best_epoch": best_epoch},
                   output_dir / f"{experiment}_best_model.pt")
    return result

# %%
# OPTIONAL: Uncomment the two lines below for a very short functionality check.
# quick_conf = Config(hidden_dim=48, max_epochs=1, patience=1)
# _ = run_experiment(df, "radius_holdout", quick_conf, OUTPUT_DIR, quick_check=True)
print("Optional check skipped. Proceed to Block 11 for full experiments.")

# %%
results["random_70_15_15"] = run_experiment(
    df, "random_70_15_15", Config(), OUTPUT_DIR, quick_check=False
)
display(pd.DataFrame([results["random_70_15_15"]]))
display(Image(filename=str(OUTPUT_DIR / "random_70_15_15_fomt_parity.png")))

# %% [markdown]
# ## Block 12 — FULL training: patch-radius holdout
# 
# **Main additional validation for Comment 2.** Entire radius levels are excluded from training: 50 mm is validation and 45 mm is testing. Run after defining all previous functions. Results will be saved separately.

# %%
results["radius_holdout"] = run_experiment(
    df, "radius_holdout", Config(), OUTPUT_DIR, quick_check=False
)
display(pd.DataFrame([results["radius_holdout"]]))
display(Image(filename=str(OUTPUT_DIR / "radius_holdout_fomt_parity.png")))

# %% [markdown]
# ## Block 13 — FULL training: mutual-gap holdout
# 
# **Second additional validation for Comment 2.** Entire mutual-gap levels are excluded from training: 1.5 mm is validation and 1.0 mm is testing.

# %%
results["gap_holdout"] = run_experiment(
    df, "gap_holdout", Config(), OUTPUT_DIR, quick_check=False
)
display(pd.DataFrame([results["gap_holdout"]]))
display(Image(filename=str(OUTPUT_DIR / "gap_holdout_fomt_parity.png")))

# %%
if not results:
    raise RuntimeError('No completed full-training experiments. Run Blocks 11–13 first.')

comparison_df = pd.DataFrame(list(results.values()))
ordered = ["random_70_15_15", "radius_holdout", "gap_holdout"]
comparison_df["method"] = pd.Categorical(comparison_df["method"], categories=ordered, ordered=True)
comparison_df = comparison_df.sort_values("method").reset_index(drop=True)
comparison_csv = OUTPUT_DIR / "fomt_generalization_comparison.csv"
comparison_df.to_csv(comparison_csv, index=False)

display(comparison_df.style.format({"R2": "{:.4f}", "MAE": "{:.4f}", "MSE": "{:.4f}", "RMSE": "{:.4f}"}))
print(f"Saved comparison CSV: {comparison_csv.resolve()}")
if len(comparison_df) < 3:
    print('WARNING: Only some experiments are complete. Run all three for a full reviewer comparison.')

# %%
for method_name in ["random_70_15_15", "radius_holdout", "gap_holdout"]:
    fig_path = OUTPUT_DIR / f"{method_name}_learning_curve.png"
    if fig_path.exists():
        print(method_name)
        display(Image(filename=str(fig_path)))
    else:
        print(f"Skipped: {method_name} has not been fully trained yet.")


