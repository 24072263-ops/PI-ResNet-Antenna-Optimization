# %%
# %pip install torch numpy pandas openpyxl scikit-learn matplotlib ipykernel

# %%
from __future__ import annotations
import os
import random
from copy import deepcopy
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import TensorDataset, DataLoader

SEED = 42
SMOKE_TEST = os.getenv('ABLATION_SMOKE_TEST', '0') == '1'  # Set True only for a code check.
DATA_PATH = Path('final_sorted_dataset.xlsx')
OUTPUT_DIR = Path('reviewer2_ablation_smoke' if SMOKE_TEST else 'reviewer2_ablation_results')
OUTPUT_DIR.mkdir(exist_ok=True, parents=True)

FEATURES = ['Ant_length', 'Ant_width', 'patch_radius',
            'inset_width', 'inset_length', 'mutual_gap']
PHYS_TARGETS = ['Avg_efficiency', 'FBW', 'Total Area (mm^2)']
FOM_TARGET = 'FoMt'

WAVELENGTH = 241.12     # Same as original notebook
THETA_R = 6.283         # Same as original notebook
HIDDEN_DIM = 48 if SMOKE_TEST else 412
N_BLOCKS = 3
DROPOUT = 0.3
BATCH_SIZE = 32
LEARNING_RATE = 0.007767
MAX_EPOCHS = 2 if SMOKE_TEST else 200
EARLY_STOPPING_PATIENCE = 20
SCHEDULER_PATIENCE = 5
SCHEDULER_FACTOR = 0.5
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

print('Device:', DEVICE)
print('Mode:', 'SHORT FUNCTIONALITY CHECK — NOT FOR PUBLICATION' if SMOKE_TEST else 'FULL EXPERIMENT')
print('Dataset:', DATA_PATH.resolve())
print('Outputs:', OUTPUT_DIR.resolve())


def seed_everything(seed=SEED):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    # Deterministic algorithms where supported. CUDA operations may still differ
    # slightly across devices/library versions.
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

# %%
if not DATA_PATH.exists():
    raise FileNotFoundError(
        f'Cannot find {DATA_PATH}. Put final_sorted_dataset.xlsx alongside '
        'this notebook, or edit DATA_PATH in Block 2.'
    )
raw_df = pd.read_excel(DATA_PATH)
required = FEATURES + PHYS_TARGETS + [FOM_TARGET]
missing = [name for name in required if name not in raw_df]
if missing:
    raise ValueError(f'Missing required Excel columns: {missing}')
if raw_df[required].isna().any().any():
    raise ValueError('Dataset contains missing input or target values.')
if not np.isfinite(raw_df[required].to_numpy(dtype=np.float64)).all():
    raise ValueError('Dataset contains infinite input or target values.')

train_df, temp_df = train_test_split(raw_df, test_size=0.30, random_state=SEED)
val_df, test_df = train_test_split(temp_df, test_size=0.50, random_state=SEED)

x_scaler = StandardScaler().fit(train_df[FEATURES].to_numpy(dtype=np.float32))
phys_scaler = StandardScaler().fit(train_df[PHYS_TARGETS].to_numpy(dtype=np.float32))


def dataset_for(frame):
    x = x_scaler.transform(frame[FEATURES].to_numpy(dtype=np.float32)).astype(np.float32)
    phys = phys_scaler.transform(frame[PHYS_TARGETS].to_numpy(dtype=np.float32)).astype(np.float32)
    fom = frame[[FOM_TARGET]].to_numpy(dtype=np.float32)
    return TensorDataset(torch.from_numpy(x), torch.from_numpy(phys), torch.from_numpy(fom))


train_dataset = dataset_for(train_df)
val_dataset = dataset_for(val_df)
test_dataset = dataset_for(test_df)
assert len(train_dataset) + len(val_dataset) + len(test_dataset) == len(raw_df)
print(f'Rows: {len(raw_df)} | train: {len(train_dataset)} | '
      f'validation: {len(val_dataset)} | test: {len(test_dataset)}')

# %%
def make_loaders(seed=SEED):
    g = torch.Generator().manual_seed(seed)
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True,
                              generator=g, num_workers=0)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False,
                            num_workers=0)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False,
                             num_workers=0)
    return train_loader, val_loader, test_loader

# %%
class AblationResidualBlock(nn.Module):
    def __init__(self, hidden_dim, dropout_rate=0.3, use_skip=True):
        super().__init__()
        self.use_skip = use_skip
        self.block = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
        )
        self.activation = nn.ReLU()

    def forward(self, x):
        out = self.block(x)
        return self.activation(x + out) if self.use_skip else self.activation(out)


class FoMEquationLayer(nn.Module):
    def __init__(self, wavelength=WAVELENGTH, theta_r=THETA_R):
        super().__init__()
        self.wavelength = wavelength
        self.theta_r = theta_r
        self.register_buffer('pi', torch.tensor(3.14159265359))

    def forward(self, efficiency, fbw, area):
        numerator = efficiency * fbw
        denom = (4 * self.pi * area) / (self.theta_r * (self.wavelength ** 2))
        ratio = numerator / (denom + 1e-8)
        # Equivalent to the log-base-10 operation in the original notebook.
        return 10.0 * torch.log10(ratio + 1e-8)


class AblationPIResNet(nn.Module):
    def __init__(self, variant, physics_scaler, hidden_dim=HIDDEN_DIM,
                 num_blocks=N_BLOCKS, dropout=DROPOUT):
        super().__init__()
        self.variant = variant
        self.input_layer = nn.Sequential(nn.Linear(6, hidden_dim), nn.ReLU())
        self.backbone = nn.Sequential(*[
            AblationResidualBlock(hidden_dim, dropout, use_skip=(variant != 'no_residual'))
            for _ in range(num_blocks)
        ])
        self.register_buffer('phys_mean', torch.tensor(physics_scaler.mean_, dtype=torch.float32))
        self.register_buffer('phys_scale', torch.tensor(physics_scaler.scale_, dtype=torch.float32))
        self.head_eff = nn.Linear(hidden_dim, 1)
        self.head_fbw = nn.Linear(hidden_dim, 1)
        self.head_area = nn.Linear(hidden_dim, 1)
        self.physics_layer = FoMEquationLayer()
        # Only this *optional* ablation uses a new trainable FoMT head.
        if variant == 'no_physics_layer':
            self.head_fom = nn.Linear(hidden_dim, 1)

    def forward(self, inputs):
        features = self.backbone(self.input_layer(inputs))
        eff_scaled = self.head_eff(features)
        fbw_scaled = self.head_fbw(features)
        area_scaled = self.head_area(features)

        if self.variant == 'no_physics_layer':
            fom = self.head_fom(features)  # No physics equation in output path
        else:
            eff_real = torch.relu(eff_scaled * self.phys_scale[0] + self.phys_mean[0]) + 1e-6
            fbw_real = torch.relu(fbw_scaled * self.phys_scale[1] + self.phys_mean[1]) + 1e-6
            area_real = torch.relu(area_scaled * self.phys_scale[2] + self.phys_mean[2]) + 1e-6
            fom = self.physics_layer(eff_real, fbw_real, area_real)
        return fom, eff_scaled, fbw_scaled, area_scaled


VARIANTS = {
    'full': 'Full PI-ResNet (four supervised tasks + physics formula + skips)',
    'no_fomt_loss': 'Without FoMT loss (three auxiliary losses; physics formula retained)',
    'no_residual': 'Without residual/skip connections',
    'no_multitask': 'Without auxiliary multi-task losses (FoMT loss only)',
    'no_physics_layer': 'Optional: direct FoMT head (physics equation removed)',
}

# %%
loss_fn = nn.HuberLoss(delta=1.0)


def training_loss(variant, predictions, y_phys_scaled, y_fomt):
    pred_fomt, pred_eff, pred_fbw, pred_area = predictions
    l_fomt = loss_fn(pred_fomt, y_fomt)
    l_eff = loss_fn(pred_eff, y_phys_scaled[:, 0:1])
    l_fbw = loss_fn(pred_fbw, y_phys_scaled[:, 1:2])
    l_area = loss_fn(pred_area, y_phys_scaled[:, 2:3])
    if variant == 'no_fomt_loss':
        return l_eff + l_fbw + l_area
    if variant == 'no_multitask':
        return l_fomt
    return l_fomt + l_eff + l_fbw + l_area


def get_metrics(y_true, y_pred):
    return {
        'R2': float(r2_score(y_true, y_pred)),
        'MAE': float(mean_absolute_error(y_true, y_pred)),
        'MSE': float(mean_squared_error(y_true, y_pred)),
        'RMSE': float(np.sqrt(mean_squared_error(y_true, y_pred))),
    }

# %%
results = {}


def fit_and_evaluate(variant, seed=SEED):
    if variant not in VARIANTS:
        raise KeyError(f'Unrecognized variant: {variant}')
    seed_everything(seed)
    train_loader, val_loader, test_loader = make_loaders(seed)
    model = AblationPIResNet(variant, phys_scaler).to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=SCHEDULER_FACTOR,
        patience=SCHEDULER_PATIENCE
    )
    best_val = float('inf')
    best_weights = None
    best_epoch = -1
    no_improvement = 0
    history = []

    print(f'\n--- Training {variant}: {VARIANTS[variant]} ---')
    for epoch in range(1, MAX_EPOCHS + 1):
        model.train()
        train_sum, train_n = 0.0, 0
        for bx, py, fy in train_loader:
            bx, py, fy = bx.to(DEVICE), py.to(DEVICE), fy.to(DEVICE)
            optimizer.zero_grad()
            loss = training_loss(variant, model(bx), py, fy)
            loss.backward()
            optimizer.step()
            train_sum += float(loss.item()) * len(bx)
            train_n += len(bx)

        # Common selection metric for all variants: validation FoMT Huber loss
        model.eval()
        validation_sum, val_n = 0.0, 0
        with torch.no_grad():
            for bx, py, fy in val_loader:
                bx, fy = bx.to(DEVICE), fy.to(DEVICE)
                fom_prediction = model(bx)[0]
                fom_loss = loss_fn(fom_prediction, fy)
                validation_sum += float(fom_loss.item()) * len(bx)
                val_n += len(bx)
        val_fomt_loss = validation_sum / val_n
        train_avg = train_sum / train_n
        scheduler.step(val_fomt_loss)
        history.append({
            'epoch': epoch,
            'train_objective': train_avg,
            'val_fomt_huber': val_fomt_loss,
            'learning_rate': optimizer.param_groups[0]['lr'],
        })

        if val_fomt_loss < best_val - 1e-10:
            best_val = val_fomt_loss
            best_weights = deepcopy(model.state_dict())
            best_epoch = epoch
            no_improvement = 0
        else:
            no_improvement += 1

        if epoch == 1 or epoch % 5 == 0 or no_improvement >= EARLY_STOPPING_PATIENCE:
            print(f'{variant:18s} | epoch {epoch:3d} | '
                  f'train: {train_avg:.5f} | val FoMT: {val_fomt_loss:.5f} | '
                  f'LR: {optimizer.param_groups[0]["lr"]:.6g}')
        if no_improvement >= EARLY_STOPPING_PATIENCE:
            print('Early stopping.')
            break

    if best_weights is None:
        raise RuntimeError('No successful checkpoint; inspect your data/losses.')
    model.load_state_dict(best_weights)
    model.eval()
    y_true, y_pred = [], []
    with torch.no_grad():
        for bx, py, fy in test_loader:
            prediction = model(bx.to(DEVICE))[0].cpu().numpy().ravel()
            y_pred.extend(prediction.tolist())
            y_true.extend(fy.numpy().ravel().tolist())
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    record = {
        'model': variant,
        'description': VARIANTS[variant],
        'seed': seed,
        'samples_train': len(train_dataset),
        'samples_val': len(val_dataset),
        'samples_test': len(test_dataset),
        'best_epoch': best_epoch,
        'best_val_fomt_huber': best_val,
        'parameters': sum(p.numel() for p in model.parameters() if p.requires_grad),
        **get_metrics(y_true, y_pred),
    }

    pd.DataFrame(history).to_csv(OUTPUT_DIR / f'{variant}_history.csv', index=False)
    pd.DataFrame({'actual_FoMt': y_true, 'predicted_FoMt': y_pred,
                  'error': y_pred-y_true}).to_csv(OUTPUT_DIR / f'{variant}_test_predictions.csv', index=False)
    torch.save({'variant': variant, 'seed': seed, 'state_dict': best_weights,
                'hidden_dim': HIDDEN_DIM, 'num_blocks': N_BLOCKS},
               OUTPUT_DIR / f'{variant}_best.pth')
    results[variant] = record
    print('RESULT:', {key: round(record[key], 5) for key in ['R2', 'MAE', 'MSE', 'RMSE']})
    return record

# %%
seed_everything(SEED)
sample_x, sample_phys, sample_fomt = next(iter(make_loaders()[0]))
for variant in VARIANTS:
    model = AblationPIResNet(variant, phys_scaler, hidden_dim=48).to(DEVICE)
    out = model(sample_x.to(DEVICE))
    assert out[0].shape == sample_fomt.shape, f'Wrong FoMT shape for {variant}'
    objective = training_loss(variant, out, sample_phys.to(DEVICE), sample_fomt.to(DEVICE))
    assert torch.isfinite(objective), f'Non-finite loss for {variant}'
    objective.backward()
    assert any(p.grad is not None for p in model.parameters()), f'No gradients: {variant}'
    print(f'{variant:18s}: PASS, FoMT shape {tuple(out[0].shape)}, loss {objective.item():.4f}')

# %%
fit_and_evaluate('full')

# %%
fit_and_evaluate('no_fomt_loss')

# %%
fit_and_evaluate('no_residual')

# %%
fit_and_evaluate('no_multitask')

# %%
fit_and_evaluate('no_physics_layer')

# %%
if not results:
    raise RuntimeError('Train at least one model in Blocks 9–13 first.')
order = list(VARIANTS)
summary = pd.DataFrame([results[v] for v in order if v in results])
summary.to_csv(OUTPUT_DIR / 'ablation_summary.csv', index=False)
print('\nAblation study (FoMT test-set metrics):')
print(summary[['model', 'R2', 'MAE', 'MSE', 'RMSE', 'best_epoch',
               'best_val_fomt_huber', 'parameters']].to_string(index=False,
                                                     float_format=lambda x: f'{x:.5f}'))
print('\nSaved:', (OUTPUT_DIR / 'ablation_summary.csv').resolve())
if SMOKE_TEST:
    print('WARNING: SMOKE-TEST results MUST NOT be reported in the manuscript.')


